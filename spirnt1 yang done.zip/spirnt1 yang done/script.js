function toggleFormTambahProduk() {
    var formTambahProduk = document.getElementById("form-tambah-produk");
    if (formTambahProduk.style.display === "none") {
      formTambahProduk.style.display = "block";
    } else {
      formTambahProduk.style.display = "none";
    }
  }
  